
function mainkanGame(namaGame) {
    alert("Anda memainkan: " + namaGame + " (simulasi)");
    const audio = new Audio("assets/sound/click.mp3");
    audio.play();
}
